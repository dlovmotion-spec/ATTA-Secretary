package com.attaproductions.secretary

import android.Manifest
import android.app.*
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.speech.RecognizerIntent
import android.view.Gravity
import android.view.View
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {
    private lateinit var db: TaskDb
    private lateinit var list: LinearLayout
    private val fmt = SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault())
    private var selectedTime = System.currentTimeMillis() + 3600_000
    private lateinit var dueButton: Button
    private lateinit var titleInput: EditText
    private val speechRequest = 200

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = TaskDb(this)
        requestPermissionsIfNeeded()
        showSplash()
    }

    private fun showSplash() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setBackgroundColor(Color.rgb(17,17,17))
        }
        root.addView(TextView(this).apply {
            text = "ATTA"; textSize = 52f; setTextColor(Color.rgb(200,164,90)); typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
        })
        root.addView(TextView(this).apply {
            text = "PRODUCTIONS\nPERSONAL SECRETARY"; textSize = 16f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        })
        setContentView(root)
        root.postDelayed({ showMain() }, 1100)
    }

    private fun showMain() {
        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(28,28,28,40); setBackgroundColor(Color.rgb(247,247,247)) }
        root.addView(TextView(this).apply { text="ATTA Secretary"; textSize=28f; typeface=Typeface.DEFAULT_BOLD; setTextColor(Color.rgb(17,17,17)) })
        root.addView(TextView(this).apply { text="Ваш личный секретарь"; textSize=15f; setTextColor(Color.DKGRAY); setPadding(0,0,0,18) })

        titleInput = EditText(this).apply { hint="Что нужно напомнить?"; textSize=18f }
        root.addView(titleInput, LinearLayout.LayoutParams(-1,-2))
        val buttons = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
        val voice = Button(this).apply { text="🎙 Голос"; setOnClickListener { startVoice() } }
        dueButton = Button(this).apply { text=fmt.format(Date(selectedTime)); setOnClickListener { chooseDateTime() } }
        buttons.addView(voice, LinearLayout.LayoutParams(0,-2,1f)); buttons.addView(dueButton, LinearLayout.LayoutParams(0,-2,1f))
        root.addView(buttons)

        val add = Button(this).apply {
            text="+ ДОБАВИТЬ ЗАДАЧУ"
            setOnClickListener {
                val t=titleInput.text.toString().trim(); if(t.isEmpty()) { Toast.makeText(this@MainActivity,"Введите задачу",Toast.LENGTH_SHORT).show(); return@setOnClickListener }
                val id=db.add(t,"",selectedTime,1,"none"); schedule(id,t,selectedTime); titleInput.setText(""); selectedTime=System.currentTimeMillis()+3600_000; dueButton.text=fmt.format(Date(selectedTime)); refresh()
            }
        }
        root.addView(add)
        root.addView(TextView(this).apply { text="ЗАДАЧИ"; textSize=16f; typeface=Typeface.DEFAULT_BOLD; setPadding(0,28,0,8) })
        list=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }
        root.addView(list)
        scroll.addView(root)
        setContentView(scroll)
        refresh()
    }

    private fun refresh() {
        list.removeAllViews()
        val tasks=db.tasks(false)
        if(tasks.isEmpty()) list.addView(TextView(this).apply { text="Все задачи выполнены. Добавьте новое напоминание."; textSize=16f; setPadding(8,18,8,18) })
        tasks.forEach { task ->
            val card=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(18,16,18,16); setBackgroundColor(Color.WHITE) }
            card.addView(TextView(this).apply { text=task.title; textSize=18f; typeface=Typeface.DEFAULT_BOLD })
            card.addView(TextView(this).apply { text="⏰ ${fmt.format(Date(task.dueAt))}"; textSize=14f; setTextColor(Color.DKGRAY) })
            val row=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
            row.addView(Button(this).apply { text="✓ Готово"; setOnClickListener { db.markDone(task.id); refresh() } }, LinearLayout.LayoutParams(0,-2,1f))
            row.addView(Button(this).apply { text="Удалить"; setOnClickListener { db.delete(task.id); refresh() } }, LinearLayout.LayoutParams(0,-2,1f))
            card.addView(row)
            list.addView(card, LinearLayout.LayoutParams(-1,-2).apply { setMargins(0,0,0,12) })
        }
    }

    private fun chooseDateTime() {
        val cal=Calendar.getInstance().apply { timeInMillis=selectedTime }
        DatePickerDialog(this,{_,y,m,d ->
            val c=Calendar.getInstance(); c.set(y,m,d,cal.get(Calendar.HOUR_OF_DAY),cal.get(Calendar.MINUTE),0)
            TimePickerDialog(this,{_,h,min -> c.set(Calendar.HOUR_OF_DAY,h); c.set(Calendar.MINUTE,min); selectedTime=c.timeInMillis; dueButton.text=fmt.format(Date(selectedTime)) },cal.get(Calendar.HOUR_OF_DAY),cal.get(Calendar.MINUTE),true).show()
        },cal.get(Calendar.YEAR),cal.get(Calendar.MONTH),cal.get(Calendar.DAY_OF_MONTH)).show()
    }

    private fun schedule(id: Long, title: String, at: Long) {
        val am=getSystemService(ALARM_SERVICE) as AlarmManager
        val i=Intent(this,ReminderReceiver::class.java).putExtra("id",id).putExtra("title",title)
        val pi=PendingIntent.getBroadcast(this,id.toInt(),i,PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        try { am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,pi) } catch(_:SecurityException) { am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,pi) }
    }

    private fun startVoice() {
        val i=Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE,Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_PROMPT,"Скажите задачу")
        }
        try { startActivityForResult(i,speechRequest) } catch(_:Exception) { Toast.makeText(this,"Голосовой ввод недоступен",Toast.LENGTH_SHORT).show() }
    }

    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?) {
        super.onActivityResult(requestCode,resultCode,data)
        if(requestCode==speechRequest && resultCode==RESULT_OK) {
            val r=data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS); if(!r.isNullOrEmpty()) titleInput.setText(r[0])
        }
    }

    private fun requestPermissionsIfNeeded() {
        val p=mutableListOf<String>()
        if(android.os.Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) p += Manifest.permission.POST_NOTIFICATIONS
        if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED) p += Manifest.permission.RECORD_AUDIO
        if(p.isNotEmpty()) requestPermissions(p.toTypedArray(),100)
    }
}
